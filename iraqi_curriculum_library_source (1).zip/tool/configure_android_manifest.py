from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
if not manifest.exists():
    raise SystemExit('AndroidManifest.xml not found; run flutter create --platforms=android first.')
text = manifest.read_text(encoding='utf-8')
root_match = re.search(r'<manifest\b[^>]*>', text)
if not root_match:
    raise SystemExit('Opening <manifest> tag not found in AndroidManifest.xml.')

permissions = [
    'android.permission.INTERNET',
    'android.permission.RECEIVE_BOOT_COMPLETED',
    'android.permission.POST_NOTIFICATIONS',
]
missing = [permission for permission in permissions if f'android:name="{permission}"' not in text]
if missing:
    permission_tags = ''.join(f'\n    <uses-permission android:name="{permission}" />' for permission in missing)
    insertion_point = root_match.end()
    text = text[:insertion_point] + permission_tags + text[insertion_point:]

receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
'''
if 'com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver' not in text:
    if '</application>' not in text:
        raise SystemExit('Closing </application> tag not found in AndroidManifest.xml.')
    text = text.replace('</application>', receivers + '    </application>', 1)

manifest.write_text(text, encoding='utf-8')
print('Updated Android manifest permissions and scheduled-notification receivers.')
